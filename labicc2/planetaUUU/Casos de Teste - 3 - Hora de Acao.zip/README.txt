Arquivo zip gerado em: 21/10/2022 13:18:26 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: 3 - Hora de Ação