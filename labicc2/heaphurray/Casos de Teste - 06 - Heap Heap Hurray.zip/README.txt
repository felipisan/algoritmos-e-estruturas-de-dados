Arquivo zip gerado em: 26/11/2022 14:17:12 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: 06 - Heap Heap Hurray