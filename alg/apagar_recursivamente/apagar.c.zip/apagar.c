/*
* Nome: Felipi Yuri Santos
* NUSP: 11917292
* 
* Curso: SCC0202 - Algoritmos e Estruturas de Dados I
* Prof. Marcelo Manzato
*/

#include <stdio.h>
#include <stdlib.h>
#include "fila.h"
#include "item.h"

void fila_apagar(FILA **fila){
	if(!fila_vazia(*fila)){
    	free(fila_remover(*fila));
        fila_apagar(fila);
    }
    free(*fila);
    *fila = NULL;
}  