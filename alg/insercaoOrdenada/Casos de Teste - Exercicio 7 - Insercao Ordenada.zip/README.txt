Arquivo zip gerado em: 24/10/2022 17:21:40 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 7 - Inserção Ordenada