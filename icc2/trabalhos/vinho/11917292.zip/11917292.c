/*
* Nome: Felipi Yuri Santos
* NUSP: 11917292
* 
* Curso: SCC0201 - Introdução à Ciência de Computação II
* Prof. Fernando Pereira dos Santos
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define READLINE_BUFFER 4096
//Lê o que o usuário digita e aloca espaço da memória HEAP para armazenar essa string.
//Parâmetros:
//      - (FILE *) stream: é o local que armazenou o que o usuário digitou, geralmente é stdin  
char *readline(FILE *stream){
	char *string = 0; 	
	int pos = 0; 		

	do {
		if (pos % READLINE_BUFFER == 0) {
			string = (char *) realloc(string, 
				(pos / READLINE_BUFFER + 1) * READLINE_BUFFER);
		}
		string[pos] = (char) fgetc(stream);	
	}
	while (string[pos++] != '\n' && !feof(stream));
	string[pos-1] = '\0';
	string = (char *) realloc(string, pos);
	return string;
}

//Conta a quantidade de linhas de um arquivo.
//Parâmetros:
//      - (char *) file_name: nome do arquivo  
int countLines(char *file_name){    
    int lines = 0;
   
    FILE *temp = fopen(file_name, "r");
    char c = getc(temp);

    while (c != EOF){
        if (c == '\n')
            lines++;
        c = getc(temp);
    }
    
    fclose(temp);
    return lines;
}

//Coloca todos os registros de um arquivo CSV num vetor 
//Parâmetros:
//      - (FILE *) csv: o arquivo sendo lido
//      - (char *) file_name: o nome do arquivo
//      - (int *) i: ele conta quantos elementos o vetor terá (passado por referência)
float *csvToVector(FILE *csv, char *file_name, int *i){
    
    //Precisamos ignorar a primeira linha de um arquivo .csv
    fscanf(csv, "%*[^\n]\n");
    
    int file_line_ct = countLines(file_name);

    //Sabemos que são 6 campos para cada registro nesse "banco de dados" 
    float *vector = (float *) malloc(6 * file_line_ct * sizeof(float));
    *i = 0;
    char buffer[4096];

    while (!feof(csv)) {
        fscanf(csv, "%*[\',''\n']s"); //Pulando a vírgula se tiver e a quebra de linha
        fscanf(csv, "%[^\','^\'\n']s", buffer); //Lendo a parte depois da vírgula

        vector[*i] = atof(buffer); 
        (*i)++;
    }

    return vector;
}

typedef struct wine{
    int id;
    float citric_acid;
    float residual_sugar;
    float density;
    float pH;
    float alcohol;
} wine_t;

//Põe em um único vetor de tamanho size toda os valores da característica selecionada do vinho
//Parâmetros:
//      - (wine_t **) wine_list: o ponteiro duplo que aponta pros ponteiros da struct vinho_t
//      - (float *) ordering: o novo vetor que armazenará todas as características do vinho selecionada
//      - (char *) property_name: a string do nome da característica
//      - (int) size: a quantidade de vinhos existentes no .csv
void findProperty(wine_t **wine_list, float* ordering, char *property_name, int size){
    int QUAL_MEU_DEUS = 0;

    printf("s1:%s", property_name);
    if (strcmp(property_name, "citric_acid") == 0){
        for (int i = 0; i < size; i++)
            ordering[i] = wine_list[i]->citric_acid;
        
        QUAL_MEU_DEUS = 1;
    }

    else if (strcmp(property_name, "residual_sugar") == 0){
        for (int i = 0; i < size; i++)
            ordering[i] = wine_list[i]->residual_sugar;
        
        QUAL_MEU_DEUS = 2;
    }

    else if (strcmp(property_name, "density") == 0){
        for (int i = 0; i < size; i++)
            ordering[i] = wine_list[i]->density;
        
        QUAL_MEU_DEUS = 3;
    }

    else if (strcmp(property_name, "pH") == 0){
        for (int i = 0; i < size; i++)
            ordering[i] = wine_list[i]->pH;
        
        QUAL_MEU_DEUS = 4;
    }
    
    else if (strcmp(property_name, "alcohol") == 0){
        for (int i = 0; i < size; i++)
            ordering[i] = wine_list[i]->alcohol;
        
        QUAL_MEU_DEUS = 5;
    }

    printf("OLHA ISSO DAQUI: %d\n", QUAL_MEU_DEUS);
}

void wineSort(wine_t **wine_list, char *property_name, int size){

    float *ordering = (float *) malloc(size * sizeof(float));
    findProperty(wine_list, ordering, property_name, size);

    int i, j, max_position;
    for (i = 0; i < size - 1; i++){
        max_position = i;
        for (j = i + 1; j < size; j++){
            int a = wine_list[j]->id;
            int b = wine_list[max_position]->id;
            
            if (ordering[j] > ordering[max_position])
                max_position = j;
            else if(ordering[j] == ordering[max_position])
                if (a > b)
                    max_position = j;
        }
        
        if(max_position != i){
            float aux = ordering[max_position];
            ordering[max_position] = ordering[i];
            ordering[i] = aux;

            wine_t *tmp = wine_list[max_position];
            wine_list[max_position] = wine_list[i];
            wine_list[i] = tmp;
        }
    }
    free(ordering);
}

void invertOrder(wine_t **wine_list, int size){
    for (int i = 0; i < size/2; i++){
        wine_t *aux = wine_list[i]; 
        wine_list[i] = wine_list[size - i - 1];
        wine_list[size - i - 1] = aux;  
    }
}

int binarySearch(wine_t** v, int ini, int end, int key){
	int centro = (int)((ini+end)/2);
	
	if (key == v[centro]->id)
		return centro; 
	if (ini > end) 
		return -1; 
	if (key < v[centro]) 
		return binarySearch(v, ini, centro-1, key);
	if (key > v[centro])
		return binarySearch(v, centro+1, end, key); 
}


int main(){

    //Parte 1: abrindo o arquivo e colocando todos seus valores num vetor único 
    //1º leitura do usuário: nome do arquivo
    char *file_name = readline(stdin); 
    FILE *csvFile = fopen(file_name, "r");
     
    //Tamanho do vetor propriedades
    int properties_count = 0; 
    float *property_value = csvToVector(csvFile, file_name, &properties_count);
    
    fclose(csvFile);
    free(file_name);

    //------------------------------------------------------------------------------
    //Parte 2: Determinando a quantidade de vinhos no arquivo, sabendo que trabalharemos com 6 campos.
    //Colocando todos esses dados num vetor de ponteiro duplo que aponta para ponteiros de struct wine_T

    int wineListSize = properties_count/6;
    wine_t **wine_list = (wine_t**) malloc((wineListSize) * sizeof(wine_t *));

    int i = 0;
    for (int k = 0; k < wineListSize; k++){
        wine_list[k] = (wine_t*) malloc(sizeof(wine_t));
            wine_list[k]->id = (int) property_value[i++];
            wine_list[k]->citric_acid = property_value[i++];
            wine_list[k]->residual_sugar = property_value[i++];
            wine_list[k]->density = property_value[i++];
            wine_list[k]->pH = property_value[i++];
            wine_list[k]->alcohol = property_value[i++];
    }
    free(property_value);


    //------------------------------------------------------------------------------
    //Parte 3: Ordenando de acordo com o campo desejado
    //2º leitura do usuário: dados para as buscas

    int searches;
    scanf("%d", &searches);

    for(int k = 0; k < searches; i++){
        char field[25];
        scanf("%s", field);
        
        //Primeiro preparamos o vetor para a busca, ordenando-o adequadamente
        wineSort(wine_list, field, wineListSize);
        invertOrder(wine_list, wineListSize); 
        

        float value;
        scanf(" %f", &value);

        // binarySearch(wine_list)
    }


    for (int k = 0; k < wineListSize; k++){
        // printf("\n");
        // printf("id: %d\n", wine_list[k]->id);
        // printf("citric_acid: %.5f\n", wine_list[k]->citric_acid);
        // printf("residual_sugar: %.5f\n", wine_list[k]->residual_sugar);
        // printf("density: %.5f\n", wine_list[k]->density);
        // printf("pH: %.5f\n", wine_list[k]->pH);
        // printf("alcohol: %.5f\n", wine_list[k]->alcohol);
        free(wine_list[k]);
    }

    free(wine_list);
   
    return 0;
}